import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import { AuthState, User } from '../types';
import authService from '../services/authService';

// Default auth state
const defaultAuthState: AuthState = {
  isAuthenticated: false,
  user: null,
  loading: true,
  error: null
};

// Create context
const AuthContext = createContext<{
  authState: AuthState;
  login: (email: string) => Promise<void>;
  logout: () => Promise<void>;
}>({
  authState: defaultAuthState,
  login: async () => {},
  logout: async () => {}
});

// Auth Provider component
export const AuthProvider: React.FC<{children: ReactNode}> = ({ children }) => {
  const [authState, setAuthState] = useState<AuthState>(defaultAuthState);

  // Check if user is already logged in on mount
  useEffect(() => {
    const checkAuthStatus = () => {
      const user = authService.getCurrentUser();
      if (user) {
        setAuthState({
          isAuthenticated: true,
          user,
          loading: false,
          error: null
        });
      } else {
        setAuthState({
          ...defaultAuthState,
          loading: false
        });
      }
    };

    checkAuthStatus();
  }, []);

  // Login function
  const login = async (email: string) => {
    setAuthState({
      ...authState,
      loading: true,
      error: null
    });

    try {
      const user = await authService.login(email);
      setAuthState({
        isAuthenticated: true,
        user,
        loading: false,
        error: null
      });
    } catch (error) {
      setAuthState({
        ...authState,
        loading: false,
        error: (error as Error).message
      });
      throw error;
    }
  };

  // Logout function
  const logout = async () => {
    setAuthState({
      ...authState,
      loading: true
    });

    try {
      await authService.logout();
      setAuthState({
        isAuthenticated: false,
        user: null,
        loading: false,
        error: null
      });
    } catch (error) {
      setAuthState({
        ...authState,
        loading: false,
        error: (error as Error).message
      });
      throw error;
    }
  };

  return (
    <AuthContext.Provider value={{ authState, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

// Custom hook to use auth context
export const useAuth = () => useContext(AuthContext);