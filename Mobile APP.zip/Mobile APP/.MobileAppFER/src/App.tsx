import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Transfer from './pages/Transfer';
import Transactions from './pages/Transactions';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AccountProvider } from './context/AccountContext';
import { TransactionProvider } from './context/TransactionContext';
import { initializeMockData } from './services/mockData';

// Protected route component
const ProtectedRoute: React.FC<{ element: React.ReactNode }> = ({ element }) => {
  const { authState } = useAuth();
  
  // If the authentication state is still loading, show a loading spinner
  if (authState.loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-800"></div>
      </div>
    );
  }
  
  // If not authenticated, redirect to login
  if (!authState.isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  
  // If authenticated, render the protected component
  return <>{element}</>;
};

const AppRoutes: React.FC = () => {
  const { authState } = useAuth();
  
  return (
    <Router>
      <Routes>
        <Route 
          path="/login" 
          element={authState.isAuthenticated ? <Navigate to="/" replace /> : <Login />} 
        />
        <Route path="/" element={<ProtectedRoute element={<Dashboard />} />} />
        <Route path="/transfer" element={<ProtectedRoute element={<Transfer />} />} />
        <Route path="/transactions" element={<ProtectedRoute element={<Transactions />} />} />
        
        {/* Catch all route - redirect to dashboard if authenticated, login otherwise */}
        <Route 
          path="*" 
          element={authState.isAuthenticated ? <Navigate to="/" replace /> : <Navigate to="/login" replace />} 
        />
      </Routes>
    </Router>
  );
};

function App() {
  // Initialize mock data on app start
  useEffect(() => {
    initializeMockData();
  }, []);

  return (
    <AuthProvider>
      <AccountProvider>
        <TransactionProvider>
          <AppRoutes />
        </TransactionProvider>
      </AccountProvider>
    </AuthProvider>
  );
}

export default App;