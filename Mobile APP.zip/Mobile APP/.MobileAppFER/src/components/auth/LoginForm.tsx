import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Mail } from 'lucide-react';
import Button from '../ui/Button';
import Input from '../ui/Input';

const LoginForm: React.FC = () => {
  const { authState, login } = useAuth();
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!email.trim()) {
      setError('Email is required');
      return;
    }
    
    if (!email.includes('@')) {
      setError('Please enter a valid email address');
      return;
    }
    
    try {
      await login(email);
    } catch (err) {
      setError((err as Error).message);
    }
  };

  return (
    <form onSubmit={handleLogin} className="space-y-6">
      <div>
        <Input
          id="email"
          type="email"
          label="Email"
          placeholder="Enter your email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          icon={<Mail size={18} />}
          fullWidth
          error={error || authState.error || ''}
          autoComplete="email"
          required
        />
      </div>
      
      <div>
        <Button
          type="submit"
          variant="primary"
          isLoading={authState.loading}
          className="w-full"
        >
          Sign In
        </Button>
      </div>
      
      <div className="text-center text-sm text-gray-500">
        <p>For demo purposes, you can login with:</p>
        <p className="font-medium mt-1">john@example.com or jane@example.com</p>
      </div>
    </form>
  );
};

export default LoginForm;