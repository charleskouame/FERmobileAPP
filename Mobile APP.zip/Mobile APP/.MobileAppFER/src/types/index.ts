// Define the core types for the application

export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
}

export interface Account {
  id: string;
  accountNumber: string;
  balance: number;
  ownerId: string;
  type: 'Checking' | 'Savings' | 'Investment';
  currency: string;
}

export interface Transaction {
  id: string;
  senderId: string;
  receiverId: string;
  senderAccountId: string;
  receiverAccountId: string;
  amount: number;
  timestamp: string;
  description: string;
  status: 'completed' | 'pending' | 'failed';
}

export interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
  loading: boolean;
  error: string | null;
}

export interface AccountsState {
  accounts: Account[];
  selectedAccount: Account | null;
  loading: boolean;
  error: string | null;
}

export interface TransactionsState {
  transactions: Transaction[];
  loading: boolean;
  error: string | null;
}

export interface TransferFormData {
  amount: number;
  receiverAccountNumber: string;
  description: string;
  sourceAccountId: string;
}