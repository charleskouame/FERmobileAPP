import React from 'react';
import { useTransactions } from '../../context/TransactionContext';
import { useAccounts } from '../../context/AccountContext';
import Card from '../ui/Card';
import { ArrowUpRight, ArrowDownLeft, Clock } from 'lucide-react';

const RecentTransactions: React.FC = () => {
  const { transactionsState } = useTransactions();
  const { accountsState } = useAccounts();

  if (!accountsState.selectedAccount) {
    return null;
  }

  if (transactionsState.loading) {
    return (
      <div className="animate-pulse">
        <div className="h-8 bg-gray-200 rounded mb-4 w-1/3"></div>
        <div className="space-y-3">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-16 bg-gray-200 rounded"></div>
          ))}
        </div>
      </div>
    );
  }

  if (transactionsState.error) {
    return (
      <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded relative" role="alert">
        <strong className="font-bold">Error: </strong>
        <span className="block sm:inline">{transactionsState.error}</span>
      </div>
    );
  }

  // Get only the 5 most recent transactions
  const recentTransactions = transactionsState.transactions.slice(0, 5);

  if (recentTransactions.length === 0) {
    return (
      <Card className="mt-6">
        <h2 className="text-xl font-semibold text-gray-800 mb-4">Recent Transactions</h2>
        <div className="text-center py-6">
          <Clock size={40} className="mx-auto text-gray-400 mb-3" />
          <p className="text-gray-500">No recent transactions</p>
        </div>
      </Card>
    );
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <Card className="mt-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold text-gray-800">Recent Transactions</h2>
        <a href="/transactions" className="text-blue-600 text-sm font-medium hover:text-blue-800">
          View All
        </a>
      </div>
      
      <div className="space-y-3">
        {recentTransactions.map((transaction) => {
          const isOutgoing = transaction.senderAccountId === accountsState.selectedAccount?.id;
          
          return (
            <div 
              key={transaction.id}
              className="flex items-center justify-between p-3 rounded-lg hover:bg-gray-50"
            >
              <div className="flex items-center">
                <div className={`p-2 rounded-full ${
                  isOutgoing ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'
                }`}>
                  {isOutgoing ? <ArrowUpRight size={16} /> : <ArrowDownLeft size={16} />}
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-900">
                    {isOutgoing ? 'Sent to' : 'Received from'} #{isOutgoing ? 
                      transaction.receiverAccountId : transaction.senderAccountId}
                  </p>
                  <p className="text-xs text-gray-500">{formatDate(transaction.timestamp)}</p>
                </div>
              </div>
              
              <span className={`font-semibold ${
                isOutgoing ? 'text-red-600' : 'text-green-600'
              }`}>
                {isOutgoing ? '-' : '+'} ${transaction.amount.toLocaleString('en-US', {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2
                })}
              </span>
            </div>
          );
        })}
      </div>
    </Card>
  );
};

export default RecentTransactions;