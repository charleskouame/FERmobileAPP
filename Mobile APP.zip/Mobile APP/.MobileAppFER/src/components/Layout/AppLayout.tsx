import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useAccounts } from '../../context/AccountContext';
import { 
  Home, 
  BarChart3, 
  Send, 
  CreditCard, 
  Settings, 
  LogOut, 
  Menu,
  X,
  User
} from 'lucide-react';
import Button from '../ui/Button';

interface AppLayoutProps {
  children: React.ReactNode;
  title: string;
}

const AppLayout: React.FC<AppLayoutProps> = ({ children, title }) => {
  const { authState, logout } = useAuth();
  const { accountsState } = useAccounts();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleLogout = async () => {
    try {
      await logout();
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  const navItems = [
    { icon: <Home size={20} />, label: 'Dashboard', path: '/' },
    { icon: <Send size={20} />, label: 'Transfer', path: '/transfer' },
    { icon: <BarChart3 size={20} />, label: 'Transactions', path: '/transactions' },
    { icon: <CreditCard size={20} />, label: 'Accounts', path: '/accounts' },
    { icon: <Settings size={20} />, label: 'Settings', path: '/settings' },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0 flex items-center">
                <CreditCard className="h-8 w-8 text-blue-800" />
                <span className="ml-2 text-xl font-bold text-blue-900">MoneyTransfer</span>
              </div>
            </div>
            
            {/* Mobile menu button */}
            <div className="flex items-center md:hidden">
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100 focus:outline-none"
              >
                {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
            
            {/* Desktop nav */}
            <div className="hidden md:flex md:items-center md:space-x-4">
              {authState.user && (
                <div className="flex items-center space-x-3">
                  <div className="text-right mr-2">
                    <p className="text-sm font-medium text-gray-900">{authState.user.name}</p>
                    <p className="text-xs text-gray-500">{authState.user.email}</p>
                  </div>
                  <div className="flex-shrink-0">
                    {authState.user.avatar ? (
                      <img
                        className="h-8 w-8 rounded-full"
                        src={authState.user.avatar}
                        alt={authState.user.name}
                      />
                    ) : (
                      <div className="h-8 w-8 rounded-full bg-blue-800 text-white flex items-center justify-center">
                        <User size={18} />
                      </div>
                    )}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleLogout}
                    icon={<LogOut size={16} />}
                  >
                    Logout
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Mobile menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white shadow-md">
          <div className="pt-2 pb-3 space-y-1 px-4">
            {navItems.map((item, idx) => (
              <a
                key={idx}
                href={item.path}
                className="flex items-center px-3 py-2 rounded-md text-base font-medium text-gray-900 hover:bg-gray-100"
              >
                <span className="mr-3 text-gray-500">{item.icon}</span>
                {item.label}
              </a>
            ))}
            
            {authState.user && (
              <div className="mt-4 pt-4 border-t border-gray-200">
                <div className="flex items-center px-3 py-2">
                  <div className="flex-shrink-0">
                    {authState.user.avatar ? (
                      <img
                        className="h-10 w-10 rounded-full"
                        src={authState.user.avatar}
                        alt={authState.user.name}
                      />
                    ) : (
                      <div className="h-10 w-10 rounded-full bg-blue-800 text-white flex items-center justify-center">
                        <User size={20} />
                      </div>
                    )}
                  </div>
                  <div className="ml-3">
                    <p className="text-base font-medium text-gray-900">{authState.user.name}</p>
                    <p className="text-sm text-gray-500">{authState.user.email}</p>
                  </div>
                </div>
                <button
                  onClick={handleLogout}
                  className="mt-2 w-full flex items-center px-3 py-2 rounded-md text-base font-medium text-red-600 hover:bg-red-50"
                >
                  <LogOut size={20} className="mr-3" />
                  Logout
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Sidebar & Main Content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar - Desktop only */}
        <div className="hidden md:flex md:flex-shrink-0">
          <div className="flex flex-col w-64 bg-white shadow-md">
            <div className="flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
              <nav className="mt-5 flex-1 px-2 space-y-1">
                {navItems.map((item, idx) => (
                  <a
                    key={idx}
                    href={item.path}
                    className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-700 hover:bg-blue-50 hover:text-blue-800"
                  >
                    <span className="mr-3 text-gray-500 group-hover:text-blue-800">{item.icon}</span>
                    {item.label}
                  </a>
                ))}
              </nav>
              
              {/* Account Selector */}
              {accountsState.accounts.length > 0 && (
                <div className="px-3 mt-6">
                  <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                    Your Accounts
                  </h3>
                  <div className="mt-2 space-y-1">
                    {accountsState.accounts.map((account) => (
                      <button
                        key={account.id}
                        className={`w-full group flex items-center px-2 py-2 text-sm font-medium rounded-md ${
                          accountsState.selectedAccount?.id === account.id
                            ? 'bg-blue-100 text-blue-900'
                            : 'text-gray-700 hover:bg-blue-50 hover:text-blue-800'
                        }`}
                      >
                        <CreditCard 
                          size={16} 
                          className={`mr-3 ${
                            accountsState.selectedAccount?.id === account.id
                              ? 'text-blue-800'
                              : 'text-gray-500 group-hover:text-blue-800'
                          }`} 
                        />
                        <div className="flex flex-col items-start">
                          <span className="text-sm">{account.type}</span>
                          <span className="text-xs text-gray-500">
                            {account.accountNumber}
                          </span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Main content */}
        <main className="flex-1 overflow-y-auto bg-gray-50 p-4 md:p-6">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-2xl font-semibold text-gray-900 mb-6">{title}</h1>
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};

export default AppLayout;