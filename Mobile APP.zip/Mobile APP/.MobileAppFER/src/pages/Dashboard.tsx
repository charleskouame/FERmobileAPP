import React from 'react';
import AppLayout from '../components/Layout/AppLayout';
import AccountSummary from '../components/dashboard/AccountSummary';
import RecentTransactions from '../components/dashboard/RecentTransactions';
import QuickActions from '../components/dashboard/QuickActions';

const Dashboard: React.FC = () => {
  return (
    <AppLayout title="Dashboard">
      <div className="space-y-6">
        <AccountSummary />
        <QuickActions />
        <RecentTransactions />
      </div>
    </AppLayout>
  );
};

export default Dashboard;