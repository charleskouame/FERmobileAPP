import React from 'react';
import Card from '../ui/Card';
import Button from '../ui/Button';
import { CheckCircle, Home } from 'lucide-react';
import { Transaction } from '../../types';
import { useNavigate } from 'react-router-dom';

interface TransferConfirmationProps {
  transaction: Transaction;
  onNewTransfer: () => void;
}

const TransferConfirmation: React.FC<TransferConfirmationProps> = ({
  transaction,
  onNewTransfer
}) => {
  const navigate = useNavigate();
  
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <Card className="text-center">
      <div className="flex flex-col items-center py-6">
        <div className="rounded-full bg-green-100 p-3 mb-4">
          <CheckCircle size={48} className="text-green-600" />
        </div>
        
        <h2 className="text-2xl font-bold text-green-600 mb-2">Transfer Successful!</h2>
        <p className="text-gray-500 mb-6">
          Your money has been successfully transferred.
        </p>
        
        <div className="w-full max-w-md bg-gray-50 rounded-lg p-4 mb-6">
          <div className="flex justify-between mb-2">
            <span className="text-gray-500">Amount</span>
            <span className="font-semibold">${transaction.amount.toFixed(2)}</span>
          </div>
          <div className="flex justify-between mb-2">
            <span className="text-gray-500">To Account</span>
            <span className="font-semibold">#{transaction.receiverAccountId}</span>
          </div>
          <div className="flex justify-between mb-2">
            <span className="text-gray-500">From Account</span>
            <span className="font-semibold">#{transaction.senderAccountId}</span>
          </div>
          <div className="flex justify-between mb-2">
            <span className="text-gray-500">Date & Time</span>
            <span className="font-semibold">{formatDate(transaction.timestamp)}</span>
          </div>
          <div className="flex justify-between mb-2">
            <span className="text-gray-500">Description</span>
            <span className="font-semibold">{transaction.description}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-500">Transaction ID</span>
            <span className="font-semibold">{transaction.id.slice(0, 8)}</span>
          </div>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3 w-full max-w-md">
          <Button
            variant="outline"
            icon={<Home size={18} />}
            onClick={() => navigate('/')}
            className="flex-1"
          >
            Dashboard
          </Button>
          <Button
            variant="primary"
            onClick={onNewTransfer}
            className="flex-1"
          >
            New Transfer
          </Button>
        </div>
      </div>
    </Card>
  );
};

export default TransferConfirmation;