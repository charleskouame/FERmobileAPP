import React from 'react';
import { useAccounts } from '../../context/AccountContext';
import Card from '../ui/Card';
import { CreditCard, PiggyBank, TrendingUp } from 'lucide-react';

const AccountSummary: React.FC = () => {
  const { accountsState, selectAccount } = useAccounts();

  if (accountsState.loading) {
    return (
      <div className="animate-pulse">
        <div className="h-8 bg-gray-200 rounded mb-4 w-1/4"></div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-40 bg-gray-200 rounded"></div>
          ))}
        </div>
      </div>
    );
  }

  if (accountsState.error) {
    return (
      <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded relative" role="alert">
        <strong className="font-bold">Error: </strong>
        <span className="block sm:inline">{accountsState.error}</span>
      </div>
    );
  }

  if (accountsState.accounts.length === 0) {
    return (
      <Card className="text-center py-8">
        <PiggyBank size={48} className="mx-auto text-gray-400 mb-4" />
        <h3 className="text-lg font-medium text-gray-900">No accounts found</h3>
        <p className="text-gray-500 mt-1">You don't have any accounts yet.</p>
      </Card>
    );
  }

  const getAccountIcon = (type: string) => {
    switch (type) {
      case 'Savings':
        return <PiggyBank size={24} className="text-green-600" />;
      case 'Investment':
        return <TrendingUp size={24} className="text-purple-600" />;
      default:
        return <CreditCard size={24} className="text-blue-600" />;
    }
  };

  return (
    <div>
      <h2 className="text-xl font-semibold text-gray-800 mb-4">Your Accounts</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {accountsState.accounts.map((account) => (
          <Card 
            key={account.id}
            className={`cursor-pointer transition-transform transform hover:scale-105 ${
              accountsState.selectedAccount?.id === account.id ? 'ring-2 ring-blue-500' : ''
            }`}
            onClick={() => selectAccount(account)}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center">
                <div className="p-2 rounded-full bg-gray-100">
                  {getAccountIcon(account.type)}
                </div>
                <div className="ml-3">
                  <h3 className="text-lg font-medium text-gray-900">{account.type}</h3>
                  <p className="text-sm text-gray-500">Account #{account.accountNumber}</p>
                </div>
              </div>
            </div>
            
            <div className="mt-4">
              <p className="text-sm text-gray-500">Available Balance</p>
              <p className="text-2xl font-bold mt-1">
                {account.currency} {account.balance.toLocaleString('en-US', {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2
                })}
              </p>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default AccountSummary;