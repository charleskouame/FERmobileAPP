import React, { useState } from 'react';
import { useTransactions } from '../../context/TransactionContext';
import { useAccounts } from '../../context/AccountContext';
import Card from '../ui/Card';
import { ArrowUpRight, ArrowDownLeft, Search, Filter } from 'lucide-react';
import Input from '../ui/Input';
import { Transaction } from '../../types';

const TransactionList: React.FC = () => {
  const { transactionsState } = useTransactions();
  const { accountsState } = useAccounts();
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState<'all' | 'sent' | 'received'>('all');

  if (transactionsState.loading) {
    return (
      <div className="animate-pulse">
        <div className="h-12 bg-gray-200 rounded mb-4"></div>
        <div className="space-y-3">
          {[1, 2, 3, 4, 5].map(i => (
            <div key={i} className="h-16 bg-gray-200 rounded"></div>
          ))}
        </div>
      </div>
    );
  }

  if (transactionsState.error) {
    return (
      <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded relative" role="alert">
        <strong className="font-bold">Error: </strong>
        <span className="block sm:inline">{transactionsState.error}</span>
      </div>
    );
  }

  if (!accountsState.selectedAccount) {
    return (
      <Card>
        <p className="text-center text-gray-600">Please select an account to view transactions.</p>
      </Card>
    );
  }

  // Filter and search transactions
  const filteredTransactions = transactionsState.transactions.filter((transaction) => {
    const matchesSearch = searchTerm === '' || 
      transaction.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.amount.toString().includes(searchTerm);
    
    const matchesFilter = filter === 'all' || 
      (filter === 'sent' && transaction.senderAccountId === accountsState.selectedAccount?.id) ||
      (filter === 'received' && transaction.receiverAccountId === accountsState.selectedAccount?.id);
    
    return matchesSearch && matchesFilter;
  });

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Group transactions by date (today, yesterday, older)
  const groupTransactionsByDate = (transactions: Transaction[]) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    const groups: {[key: string]: Transaction[]} = {
      'Today': [],
      'Yesterday': [],
      'This Week': [],
      'This Month': [],
      'Older': []
    };
    
    transactions.forEach(transaction => {
      const transactionDate = new Date(transaction.timestamp);
      transactionDate.setHours(0, 0, 0, 0);
      
      if (transactionDate.getTime() === today.getTime()) {
        groups['Today'].push(transaction);
      } else if (transactionDate.getTime() === yesterday.getTime()) {
        groups['Yesterday'].push(transaction);
      } else if (today.getTime() - transactionDate.getTime() < 7 * 24 * 60 * 60 * 1000) {
        groups['This Week'].push(transaction);
      } else if (today.getMonth() === transactionDate.getMonth() && 
                today.getFullYear() === transactionDate.getFullYear()) {
        groups['This Month'].push(transaction);
      } else {
        groups['Older'].push(transaction);
      }
    });
    
    return groups;
  };

  const groupedTransactions = groupTransactionsByDate(filteredTransactions);

  return (
    <div>
      <Card className="mb-6">
        <div className="flex flex-col md:flex-row md:items-center gap-4">
          <div className="flex-grow">
            <Input
              placeholder="Search transactions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              icon={<Search size={18} />}
              fullWidth
            />
          </div>
          <div className="flex items-center space-x-2">
            <Filter size={18} className="text-gray-500" />
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value as any)}
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="all">All Transactions</option>
              <option value="sent">Money Sent</option>
              <option value="received">Money Received</option>
            </select>
          </div>
        </div>
      </Card>
      
      {Object.entries(groupedTransactions).map(([datePeriod, transactions]) => 
        transactions.length > 0 && (
          <div key={datePeriod} className="mb-6">
            <h3 className="text-sm font-medium text-gray-500 mb-2">{datePeriod}</h3>
            <Card padding="none">
              <div className="divide-y divide-gray-100">
                {transactions.map((transaction) => {
                  const isOutgoing = transaction.senderAccountId === accountsState.selectedAccount?.id;
                  
                  return (
                    <div 
                      key={transaction.id}
                      className="flex items-center justify-between p-4 hover:bg-gray-50"
                    >
                      <div className="flex items-center">
                        <div className={`p-2 rounded-full ${
                          isOutgoing ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'
                        }`}>
                          {isOutgoing ? <ArrowUpRight size={18} /> : <ArrowDownLeft size={18} />}
                        </div>
                        <div className="ml-3">
                          <p className="text-sm font-medium text-gray-900">
                            {isOutgoing ? 'To: ' : 'From: '}
                            {isOutgoing ? 
                              transaction.receiverAccountId : transaction.senderAccountId}
                          </p>
                          <p className="text-xs text-gray-500">{formatDate(transaction.timestamp)}</p>
                          <p className="text-xs text-gray-700 mt-1">{transaction.description}</p>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <span className={`font-semibold ${
                          isOutgoing ? 'text-red-600' : 'text-green-600'
                        }`}>
                          {isOutgoing ? '-' : '+'} ${transaction.amount.toLocaleString('en-US', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                          })}
                        </span>
                        <p className="text-xs text-gray-500 mt-1">ID: {transaction.id.slice(0, 8)}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </Card>
          </div>
        )
      )}
      
      {filteredTransactions.length === 0 && (
        <Card className="text-center py-8">
          <Search size={40} className="mx-auto text-gray-400 mb-3" />
          <h3 className="text-lg font-medium text-gray-900">No transactions found</h3>
          <p className="text-gray-500 mt-1">
            {searchTerm ? 'Try adjusting your search parameters' : 'No transactions yet for this account'}
          </p>
        </Card>
      )}
    </div>
  );
};

export default TransactionList;