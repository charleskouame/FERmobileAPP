// Account service to handle account-related operations

import { Account, User } from '../types';
import { mockAccounts } from './mockData';

class AccountService {
  getAccounts(userId: string): Promise<Account[]> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const accounts = JSON.parse(localStorage.getItem('accounts') || JSON.stringify(mockAccounts));
        const userAccounts = accounts.filter((account: Account) => account.ownerId === userId);
        resolve(userAccounts);
      }, 600);
    });
  }

  getAccountByNumber(accountNumber: string): Promise<Account | null> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const accounts = JSON.parse(localStorage.getItem('accounts') || JSON.stringify(mockAccounts));
        const account = accounts.find((acc: Account) => acc.accountNumber === accountNumber);
        resolve(account || null);
      }, 300);
    });
  }

  updateAccountBalance(accountId: string, newBalance: number): Promise<Account> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const accounts = JSON.parse(localStorage.getItem('accounts') || JSON.stringify(mockAccounts));
        const accountIndex = accounts.findIndex((acc: Account) => acc.id === accountId);
        
        if (accountIndex !== -1) {
          accounts[accountIndex].balance = newBalance;
          localStorage.setItem('accounts', JSON.stringify(accounts));
          resolve(accounts[accountIndex]);
        } else {
          reject(new Error('Account not found'));
        }
      }, 500);
    });
  }

  createAccount(user: User, accountType: 'Checking' | 'Savings' | 'Investment'): Promise<Account> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const accounts = JSON.parse(localStorage.getItem('accounts') || JSON.stringify(mockAccounts));
        
        // Generate a new account number
        const lastAccountNumber = Math.max(...accounts.map((acc: Account) => 
          parseInt(acc.accountNumber)
        ));
        
        const newAccount: Account = {
          id: (accounts.length + 1).toString(),
          accountNumber: (lastAccountNumber + 1).toString(),
          balance: 0,
          ownerId: user.id,
          type: accountType,
          currency: 'USD'
        };
        
        accounts.push(newAccount);
        localStorage.setItem('accounts', JSON.stringify(accounts));
        resolve(newAccount);
      }, 800);
    });
  }
}

export default new AccountService();