import React from 'react';
import AuthLayout from '../components/Layout/AuthLayout';
import LoginForm from '../components/auth/LoginForm';

const Login: React.FC = () => {
  return (
    <AuthLayout 
      title="Welcome Back"
      subtitle="Login to access your accounts and make transfers."
    >
      <LoginForm />
    </AuthLayout>
  );
};

export default Login;