// Authentication service to handle user login/logout

import { User } from '../types';
import { mockUsers } from './mockData';

class AuthService {
  login(email: string): Promise<User> {
    return new Promise((resolve, reject) => {
      // Simulate network delay
      setTimeout(() => {
        const users = JSON.parse(localStorage.getItem('users') || JSON.stringify(mockUsers));
        const user = users.find((u: User) => u.email === email);
        
        if (user) {
          localStorage.setItem('currentUser', JSON.stringify(user));
          resolve(user);
        } else {
          reject(new Error('User not found. Please check your email.'));
        }
      }, 800);
    });
  }

  logout(): Promise<void> {
    return new Promise((resolve) => {
      setTimeout(() => {
        localStorage.removeItem('currentUser');
        resolve();
      }, 300);
    });
  }

  getCurrentUser(): User | null {
    const userJson = localStorage.getItem('currentUser');
    if (userJson) {
      return JSON.parse(userJson);
    }
    return null;
  }

  isAuthenticated(): boolean {
    return !!this.getCurrentUser();
  }
}

export default new AuthService();