import React, { ReactNode } from 'react';

interface CardProps {
  children: ReactNode;
  className?: string;
  variant?: 'default' | 'outlined' | 'elevated';
  padding?: 'none' | 'sm' | 'md' | 'lg';
}

const Card: React.FC<CardProps> = ({
  children,
  className = '',
  variant = 'default',
  padding = 'md',
}) => {
  // Base classes
  const baseClasses = 'rounded-lg transition-shadow bg-white';
  
  // Variant classes
  const variantClasses = {
    default: 'shadow',
    outlined: 'border border-gray-200',
    elevated: 'shadow-lg'
  };
  
  // Padding classes
  const paddingClasses = {
    none: '',
    sm: 'p-3',
    md: 'p-5',
    lg: 'p-7'
  };
  
  // Combine all classes
  const cardClasses = `
    ${baseClasses}
    ${variantClasses[variant]}
    ${paddingClasses[padding]}
    ${className}
  `;

  return (
    <div className={cardClasses}>
      {children}
    </div>
  );
};

export default Card;