// Mock data for initial application state

import { User, Account, Transaction } from '../types';
import { v4 as uuidv4 } from 'uuid';

export const mockUsers: User[] = [
  {
    id: '1',
    name: 'John Doe',
    email: 'john@example.com',
    avatar: 'https://i.pravatar.cc/150?img=1',
  },
  {
    id: '2',
    name: 'Jane Smith',
    email: 'jane@example.com',
    avatar: 'https://i.pravatar.cc/150?img=5',
  },
];

export const mockAccounts: Account[] = [
  {
    id: '1',
    accountNumber: '1000001',
    balance: 5425.50,
    ownerId: '1',
    type: 'Checking',
    currency: 'USD',
  },
  {
    id: '2',
    accountNumber: '1000002',
    balance: 10750.75,
    ownerId: '1',
    type: 'Savings',
    currency: 'USD',
  },
  {
    id: '3',
    accountNumber: '2000001',
    balance: 3250.25,
    ownerId: '2',
    type: 'Checking',
    currency: 'USD',
  },
];

export const mockTransactions: Transaction[] = [
  {
    id: uuidv4(),
    senderId: '1',
    receiverId: '2',
    senderAccountId: '1',
    receiverAccountId: '3',
    amount: 500,
    timestamp: new Date(Date.now() - 86400000).toISOString(), // Yesterday
    description: 'Monthly rent payment',
    status: 'completed',
  },
  {
    id: uuidv4(),
    senderId: '2',
    receiverId: '1',
    senderAccountId: '3',
    receiverAccountId: '1',
    amount: 150.25,
    timestamp: new Date(Date.now() - 172800000).toISOString(), // 2 days ago
    description: 'Dinner split',
    status: 'completed',
  },
  {
    id: uuidv4(),
    senderId: '1',
    receiverId: '2',
    senderAccountId: '2',
    receiverAccountId: '3',
    amount: 1000,
    timestamp: new Date(Date.now() - 604800000).toISOString(), // 1 week ago
    description: 'Investment contribution',
    status: 'completed',
  },
];

// Initialize local storage with mock data
export const initializeMockData = () => {
  if (!localStorage.getItem('users')) {
    localStorage.setItem('users', JSON.stringify(mockUsers));
  }
  
  if (!localStorage.getItem('accounts')) {
    localStorage.setItem('accounts', JSON.stringify(mockAccounts));
  }
  
  if (!localStorage.getItem('transactions')) {
    localStorage.setItem('transactions', JSON.stringify(mockTransactions));
  }
};