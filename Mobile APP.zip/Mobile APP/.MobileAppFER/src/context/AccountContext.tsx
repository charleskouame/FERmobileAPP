import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import { AccountsState, Account } from '../types';
import accountService from '../services/accountService';
import { useAuth } from './AuthContext';

// Default accounts state
const defaultAccountsState: AccountsState = {
  accounts: [],
  selectedAccount: null,
  loading: false,
  error: null
};

// Create context
const AccountContext = createContext<{
  accountsState: AccountsState;
  fetchAccounts: () => Promise<void>;
  selectAccount: (account: Account) => void;
  refreshAccount: (accountId: string) => Promise<void>;
}>({
  accountsState: defaultAccountsState,
  fetchAccounts: async () => {},
  selectAccount: () => {},
  refreshAccount: async () => {}
});

// Accounts Provider component
export const AccountProvider: React.FC<{children: ReactNode}> = ({ children }) => {
  const [accountsState, setAccountsState] = useState<AccountsState>(defaultAccountsState);
  const { authState } = useAuth();

  // Fetch user accounts when authenticated
  useEffect(() => {
    if (authState.isAuthenticated && authState.user) {
      fetchAccounts();
    } else {
      // Reset accounts when logged out
      setAccountsState(defaultAccountsState);
    }
  }, [authState.isAuthenticated, authState.user]);

  // Fetch accounts function
  const fetchAccounts = async () => {
    if (!authState.user) return;

    setAccountsState({
      ...accountsState,
      loading: true,
      error: null
    });

    try {
      const userAccounts = await accountService.getAccounts(authState.user.id);
      
      // Set the first account as selected by default if none is selected
      const selectedAccount = accountsState.selectedAccount || 
        (userAccounts.length > 0 ? userAccounts[0] : null);
      
      setAccountsState({
        accounts: userAccounts,
        selectedAccount,
        loading: false,
        error: null
      });
    } catch (error) {
      setAccountsState({
        ...accountsState,
        loading: false,
        error: (error as Error).message
      });
    }
  };

  // Select account function
  const selectAccount = (account: Account) => {
    setAccountsState({
      ...accountsState,
      selectedAccount: account
    });
  };

  // Refresh a specific account
  const refreshAccount = async (accountId: string) => {
    if (!authState.user) return;

    try {
      const accounts = [...accountsState.accounts];
      const accountIndex = accounts.findIndex(acc => acc.id === accountId);

      if (accountIndex !== -1) {
        // Get fresh account data
        const updatedAccount = await accountService.getAccountByNumber(accounts[accountIndex].accountNumber);
        
        if (updatedAccount) {
          // Update in accounts list
          accounts[accountIndex] = updatedAccount;
          
          // Update selected account if needed
          const updatedSelectedAccount = 
            accountsState.selectedAccount?.id === accountId ? 
            updatedAccount : accountsState.selectedAccount;
          
          setAccountsState({
            ...accountsState,
            accounts,
            selectedAccount: updatedSelectedAccount
          });
        }
      }
    } catch (error) {
      setAccountsState({
        ...accountsState,
        error: (error as Error).message
      });
    }
  };

  return (
    <AccountContext.Provider 
      value={{ 
        accountsState, 
        fetchAccounts, 
        selectAccount,
        refreshAccount
      }}
    >
      {children}
    </AccountContext.Provider>
  );
};

// Custom hook to use accounts context
export const useAccounts = () => useContext(AccountContext);