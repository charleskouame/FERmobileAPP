import React, { useState } from 'react';
import { useTransactions } from '../../context/TransactionContext';
import { useAccounts } from '../../context/AccountContext';
import Card from '../ui/Card';
import Button from '../ui/Button';
import Input from '../ui/Input';
import { Send } from 'lucide-react';

interface TransferFormProps {
  onTransferSuccess: () => void;
}

const TransferForm: React.FC<TransferFormProps> = ({ onTransferSuccess }) => {
  const { accountsState } = useAccounts();
  const { transferMoney, transactionsState } = useTransactions();
  
  const [amount, setAmount] = useState<string>('');
  const [receiverAccountNumber, setReceiverAccountNumber] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [formErrors, setFormErrors] = useState({
    amount: '',
    receiverAccountNumber: '',
    description: ''
  });

  const validateForm = (): boolean => {
    const errors = {
      amount: '',
      receiverAccountNumber: '',
      description: ''
    };
    
    let isValid = true;
    
    // Validate amount
    if (!amount) {
      errors.amount = 'Amount is required';
      isValid = false;
    } else if (isNaN(Number(amount)) || Number(amount) <= 0) {
      errors.amount = 'Amount must be a positive number';
      isValid = false;
    } else if (
      accountsState.selectedAccount && 
      Number(amount) > accountsState.selectedAccount.balance
    ) {
      errors.amount = 'Insufficient funds';
      isValid = false;
    }
    
    // Validate receiver account
    if (!receiverAccountNumber) {
      errors.receiverAccountNumber = 'Receiver account number is required';
      isValid = false;
    } else if (
      accountsState.selectedAccount && 
      receiverAccountNumber === accountsState.selectedAccount.accountNumber
    ) {
      errors.receiverAccountNumber = 'Cannot transfer to the same account';
      isValid = false;
    }
    
    // Validate description
    if (!description) {
      errors.description = 'Description is required';
      isValid = false;
    }
    
    setFormErrors(errors);
    return isValid;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm() || !accountsState.selectedAccount) {
      return;
    }
    
    try {
      await transferMoney({
        amount: Number(amount),
        receiverAccountNumber,
        description,
        sourceAccountId: accountsState.selectedAccount.id
      });
      
      // Reset form
      setAmount('');
      setReceiverAccountNumber('');
      setDescription('');
      
      // Notify parent
      onTransferSuccess();
    } catch (error) {
      // Error is already handled in the transaction context
      console.error('Transfer failed:', error);
    }
  };

  if (!accountsState.selectedAccount) {
    return (
      <Card>
        <p className="text-center text-gray-600">Please select an account to make a transfer.</p>
      </Card>
    );
  }

  return (
    <Card>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">Transfer From</h3>
          <div className="bg-gray-50 rounded-md p-3 border border-gray-200">
            <p className="text-sm text-gray-500">Account</p>
            <p className="font-medium">{accountsState.selectedAccount.type} - {accountsState.selectedAccount.accountNumber}</p>
            <div className="mt-1 flex justify-between items-center">
              <p className="text-sm text-gray-500">Available Balance</p>
              <p className="font-semibold text-lg">
                ${accountsState.selectedAccount.balance.toLocaleString('en-US', {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2
                })}
              </p>
            </div>
          </div>
        </div>
        
        <div>
          <Input
            id="receiverAccount"
            label="Receiver Account Number"
            placeholder="Enter account number"
            value={receiverAccountNumber}
            onChange={(e) => setReceiverAccountNumber(e.target.value)}
            error={formErrors.receiverAccountNumber}
            fullWidth
            required
          />
        </div>
        
        <div>
          <Input
            id="amount"
            type="number"
            label="Amount"
            placeholder="Enter amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            error={formErrors.amount}
            fullWidth
            required
          />
        </div>
        
        <div>
          <Input
            id="description"
            label="Description"
            placeholder="What's this transfer for?"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            error={formErrors.description}
            fullWidth
            required
          />
        </div>
        
        <Button
          type="submit"
          variant="primary"
          isLoading={transactionsState.loading}
          icon={<Send size={18} />}
          className="w-full"
        >
          Transfer Money
        </Button>
        
        {transactionsState.error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
            {transactionsState.error}
          </div>
        )}
      </form>
    </Card>
  );
};

export default TransferForm;