import React from 'react';
import { useNavigate } from 'react-router-dom';
import Card from '../ui/Card';
import Button from '../ui/Button';
import { Send, RefreshCw, CreditCard, FileText } from 'lucide-react';

const QuickActions: React.FC = () => {
  const navigate = useNavigate();

  const actions = [
    {
      title: 'Transfer Money',
      description: 'Send money to another account',
      icon: <Send size={20} />,
      onClick: () => navigate('/transfer'),
      variant: 'primary'
    },
    {
      title: 'Transactions',
      description: 'View your transaction history',
      icon: <FileText size={20} />,
      onClick: () => navigate('/transactions'),
      variant: 'secondary'
    },
    {
      title: 'Manage Accounts',
      description: 'View and manage your accounts',
      icon: <CreditCard size={20} />,
      onClick: () => navigate('/accounts'),
      variant: 'outline'
    }
  ];

  return (
    <Card className="mt-6">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">Quick Actions</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {actions.map((action, index) => (
          <Button
            key={index}
            variant={action.variant as 'primary' | 'secondary' | 'outline'}
            icon={action.icon}
            onClick={action.onClick}
            className="h-auto py-3 flex-col items-center justify-center"
          >
            <span className="block text-center">{action.title}</span>
            <span className="text-xs mt-1 opacity-80">{action.description}</span>
          </Button>
        ))}
      </div>
    </Card>
  );
};

export default QuickActions;