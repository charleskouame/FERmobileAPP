import React, { useState } from 'react';
import AppLayout from '../components/Layout/AppLayout';
import TransferForm from '../components/transfer/TransferForm';
import TransferConfirmation from '../components/transfer/TransferConfirmation';
import { Transaction } from '../types';

const Transfer: React.FC = () => {
  const [transferCompleted, setTransferCompleted] = useState(false);
  const [completedTransaction, setCompletedTransaction] = useState<Transaction | null>(null);

  const handleTransferSuccess = () => {
    // Simulate getting the transaction data
    // In a real app, this would come from the API response
    const mockTransaction: Transaction = {
      id: Math.random().toString(36).substring(2, 15),
      senderId: '1',
      receiverId: '2',
      senderAccountId: '1',
      receiverAccountId: '2',
      amount: 100,
      timestamp: new Date().toISOString(),
      description: 'Test transfer',
      status: 'completed'
    };
    
    setCompletedTransaction(mockTransaction);
    setTransferCompleted(true);
  };

  const handleNewTransfer = () => {
    setTransferCompleted(false);
    setCompletedTransaction(null);
  };

  return (
    <AppLayout title="Transfer Money">
      <div className="max-w-2xl mx-auto">
        {transferCompleted && completedTransaction ? (
          <TransferConfirmation 
            transaction={completedTransaction}
            onNewTransfer={handleNewTransfer}
          />
        ) : (
          <TransferForm onTransferSuccess={handleTransferSuccess} />
        )}
      </div>
    </AppLayout>
  );
};

export default Transfer;