import React from 'react';
import AppLayout from '../components/Layout/AppLayout';
import TransactionList from '../components/transactions/TransactionList';

const Transactions: React.FC = () => {
  return (
    <AppLayout title="Transaction History">
      <TransactionList />
    </AppLayout>
  );
};

export default Transactions;