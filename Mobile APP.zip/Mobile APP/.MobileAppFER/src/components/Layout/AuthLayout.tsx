import React from 'react';
import { Banknote } from 'lucide-react';

interface AuthLayoutProps {
  children: React.ReactNode;
  title: string;
  subtitle?: string;
}

const AuthLayout: React.FC<AuthLayoutProps> = ({ children, title, subtitle }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 to-blue-700 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center bg-white p-3 rounded-full shadow-md mb-4">
            <Banknote size={32} className="text-blue-800" />
          </div>
          <h1 className="text-3xl font-bold text-white">{title}</h1>
          {subtitle && <p className="text-blue-100 mt-2">{subtitle}</p>}
        </div>
        
        <div className="bg-white rounded-lg shadow-xl p-6 md:p-8">
          {children}
        </div>
        
        <div className="text-center mt-6">
          <p className="text-blue-100 text-sm">
            © 2025 MoneyTransfer. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AuthLayout;