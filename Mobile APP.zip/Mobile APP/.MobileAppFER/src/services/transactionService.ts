// Transaction service to handle money transfers and history

import { Transaction, TransferFormData } from '../types';
import { v4 as uuidv4 } from 'uuid';
import accountService from './accountService';
import { mockTransactions } from './mockData';

class TransactionService {
  async transfer(transferData: TransferFormData, senderId: string): Promise<Transaction> {
    // Get sender account
    const accounts = JSON.parse(localStorage.getItem('accounts') || '[]');
    const senderAccount = accounts.find((acc: any) => acc.id === transferData.sourceAccountId);
    
    if (!senderAccount) {
      throw new Error('Sender account not found');
    }
    
    // Get receiver account by account number
    const receiverAccount = accounts.find((acc: any) => 
      acc.accountNumber === transferData.receiverAccountNumber
    );
    
    if (!receiverAccount) {
      throw new Error('Receiver account not found');
    }
    
    // Validate transfer amount
    if (transferData.amount <= 0) {
      throw new Error('Transfer amount must be greater than zero');
    }
    
    // Check if sender has sufficient balance
    if (senderAccount.balance < transferData.amount) {
      throw new Error('Insufficient funds');
    }
    
    // Process transfer
    try {
      // Update sender account balance
      const newSenderBalance = senderAccount.balance - transferData.amount;
      await accountService.updateAccountBalance(senderAccount.id, newSenderBalance);
      
      // Update receiver account balance
      const newReceiverBalance = receiverAccount.balance + transferData.amount;
      await accountService.updateAccountBalance(receiverAccount.id, newReceiverBalance);
      
      // Create transaction record
      const newTransaction: Transaction = {
        id: uuidv4(),
        senderId,
        receiverId: receiverAccount.ownerId,
        senderAccountId: senderAccount.id,
        receiverAccountId: receiverAccount.id,
        amount: transferData.amount,
        timestamp: new Date().toISOString(),
        description: transferData.description,
        status: 'completed'
      };
      
      // Save transaction to storage
      const transactions = JSON.parse(
        localStorage.getItem('transactions') || JSON.stringify(mockTransactions)
      );
      transactions.push(newTransaction);
      localStorage.setItem('transactions', JSON.stringify(transactions));
      
      return newTransaction;
    } catch (error) {
      throw new Error('Failed to process transfer');
    }
  }

  getTransactionHistory(accountId: string): Promise<Transaction[]> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const transactions = JSON.parse(
          localStorage.getItem('transactions') || JSON.stringify(mockTransactions)
        );
        
        const accountTransactions = transactions.filter(
          (transaction: Transaction) => 
            transaction.senderAccountId === accountId || 
            transaction.receiverAccountId === accountId
        );
        
        // Sort by timestamp (newest first)
        accountTransactions.sort((a: Transaction, b: Transaction) => 
          new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
        );
        
        resolve(accountTransactions);
      }, 700);
    });
  }

  getUserTransactions(userId: string): Promise<Transaction[]> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const transactions = JSON.parse(
          localStorage.getItem('transactions') || JSON.stringify(mockTransactions)
        );
        
        const userTransactions = transactions.filter(
          (transaction: Transaction) => 
            transaction.senderId === userId || 
            transaction.receiverId === userId
        );
        
        // Sort by timestamp (newest first)
        userTransactions.sort((a: Transaction, b: Transaction) => 
          new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
        );
        
        resolve(userTransactions);
      }, 700);
    });
  }
}

export default new TransactionService();