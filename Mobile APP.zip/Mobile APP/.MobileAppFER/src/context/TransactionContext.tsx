import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import { TransactionsState, Transaction, TransferFormData } from '../types';
import transactionService from '../services/transactionService';
import { useAuth } from './AuthContext';
import { useAccounts } from './AccountContext';

// Default transactions state
const defaultTransactionsState: TransactionsState = {
  transactions: [],
  loading: false,
  error: null
};

// Create context
const TransactionContext = createContext<{
  transactionsState: TransactionsState;
  fetchTransactions: () => Promise<void>;
  transferMoney: (transferData: TransferFormData) => Promise<Transaction>;
}>({
  transactionsState: defaultTransactionsState,
  fetchTransactions: async () => {},
  transferMoney: async () => {
    throw new Error("Not implemented");
  }
});

// Transactions Provider component
export const TransactionProvider: React.FC<{children: ReactNode}> = ({ children }) => {
  const [transactionsState, setTransactionsState] = useState<TransactionsState>(defaultTransactionsState);
  const { authState } = useAuth();
  const { accountsState, refreshAccount } = useAccounts();

  // Fetch transactions when selected account changes
  useEffect(() => {
    if (accountsState.selectedAccount) {
      fetchTransactions();
    } else {
      // Reset transactions when no account is selected
      setTransactionsState(defaultTransactionsState);
    }
  }, [accountsState.selectedAccount]);

  // Fetch transactions for the selected account
  const fetchTransactions = async () => {
    if (!accountsState.selectedAccount) return;

    setTransactionsState({
      ...transactionsState,
      loading: true,
      error: null
    });

    try {
      const accountTransactions = await transactionService.getTransactionHistory(
        accountsState.selectedAccount.id
      );
      
      setTransactionsState({
        transactions: accountTransactions,
        loading: false,
        error: null
      });
    } catch (error) {
      setTransactionsState({
        ...transactionsState,
        loading: false,
        error: (error as Error).message
      });
    }
  };

  // Transfer money function
  const transferMoney = async (transferData: TransferFormData): Promise<Transaction> => {
    if (!authState.user) {
      throw new Error("User not authenticated");
    }

    setTransactionsState({
      ...transactionsState,
      loading: true,
      error: null
    });

    try {
      // Process the transfer
      const transaction = await transactionService.transfer(
        transferData,
        authState.user.id
      );
      
      // Refresh account balances
      await refreshAccount(transferData.sourceAccountId);
      
      // Refresh transactions list
      await fetchTransactions();
      
      setTransactionsState(prev => ({
        ...prev,
        loading: false
      }));
      
      return transaction;
    } catch (error) {
      setTransactionsState({
        ...transactionsState,
        loading: false,
        error: (error as Error).message
      });
      throw error;
    }
  };

  return (
    <TransactionContext.Provider 
      value={{ 
        transactionsState, 
        fetchTransactions, 
        transferMoney
      }}
    >
      {children}
    </TransactionContext.Provider>
  );
};

// Custom hook to use transactions context
export const useTransactions = () => useContext(TransactionContext);